Not a Runkeeper export
